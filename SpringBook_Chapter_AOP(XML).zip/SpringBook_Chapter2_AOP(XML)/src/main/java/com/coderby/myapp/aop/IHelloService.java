package com.coderby.myapp.aop;

public interface IHelloService {
	String sayHello(String name);
	String sayGoodbye(String name);
}