package com.coderby.myapp.di;

public interface IHelloService {
	String sayHello(String name);
}