package com.coderby.myapp.aop;

public class HelloLog {
	public static void log() {
		System.out.println(">>>LOG<<< : " + new java.util.Date());
	}
}